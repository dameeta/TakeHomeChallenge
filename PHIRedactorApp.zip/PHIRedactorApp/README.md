
# PHI Redactor Application

## 📦 Project Structure

```
PHIRedactorApp/
├── PHIRedactorAPI/         # .NET 6 Web API Backend
│   ├── Controllers/
│   │   └── RedactionController.cs
│   ├── PHIRedactor.cs
│   └── Program.cs (auto-generated)
└── frontend/               # Vanilla JS Frontend
    └── index.html
```

## 🚀 How to Run

### 1. Backend (ASP.NET Web API)
- Open `PHIRedactorAPI` in Visual Studio
- Run the project (`dotnet run` if using CLI)
- Ensure it listens on `http://localhost:5000`

### 2. Frontend (JavaScript)
- Open `frontend/index.html` directly in your browser **OR**
- Serve via a static server:
  ```bash
  cd frontend
  python -m http.server 8080
  # OR
  npm install -g http-server
  http-server .
  ```

- Go to: `http://localhost:8080`

### ✅ Features
- Upload `.txt` files
- PHI redaction using regex (e.g., SSN, Name, DOB, etc.)
- Download sanitized file

---
