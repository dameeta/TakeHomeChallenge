
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace PHIRedactorAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RedactionController : ControllerBase
    {
        [HttpPost("redact")]
        public async Task<IActionResult> RedactFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            using var reader = new StreamReader(file.OpenReadStream());
            string content = await reader.ReadToEndAsync();
            string redacted = PHIRedactor.Redact(content);

            var bytes = Encoding.UTF8.GetBytes(redacted);
            return File(bytes, "text/plain", Path.GetFileNameWithoutExtension(file.FileName) + "_sanitized.txt");
        }
    }
}
