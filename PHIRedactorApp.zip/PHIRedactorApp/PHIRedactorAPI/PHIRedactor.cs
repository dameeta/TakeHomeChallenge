
using System.Text.RegularExpressions;

namespace PHIRedactorAPI
{
    public static class PHIRedactor
    {
        public static string Redact(string input)
        {
            string redacted = input;

            redacted = Regex.Replace(redacted, @"(?i)Patient Name:\s*[^\r\n]+", "Patient Name: [REDACTED]");
            redacted = Regex.Replace(redacted, @"(?i)Date of Birth:\s*[^\r\n]+", "Date of Birth: [REDACTED]");
            redacted = Regex.Replace(redacted, @"(?i)Social Security Number:\s*\d{3}-\d{2}-\d{4}", "Social Security Number: [REDACTED]");
            redacted = Regex.Replace(redacted, @"(?i)Address:\s*[^\r\n]+", "Address: [REDACTED]");
            redacted = Regex.Replace(redacted, @"(?i)Phone Number:\s*\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", "Phone Number: [REDACTED]");
            redacted = Regex.Replace(redacted, @"(?i)Email:\s*[^\s]+@[^\s]+\.[^\s]+", "Email: [REDACTED]");
            redacted = Regex.Replace(redacted, @"(?i)Medical Record Number:\s*[^\r\n]+", "Medical Record Number: [REDACTED]");

            return redacted;
        }
    }
}
